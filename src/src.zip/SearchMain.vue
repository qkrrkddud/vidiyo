<template>
  <main>
    <div class="popular">
      <h1>인기</h1>
      <div class="list" v-for="(vidiyo, index) in products" :key="index">
        <img v-bind:src="vidiyo.img" />
      </div>
    </div>
  </main>
</template>

<script>
export default {
  data() {
    return {
      products: [
        {
          img: this.getNumber(),
        },
      ],
    };
  },
  methods:{
    getNumber(){
      const num = Math.floor(Math.random()*11);
    //console.log(num)
      return require("../assets/image/mm"+num+".jpg");
    }
  }
};
</script>

<style scoped>
main {
  width: 100%;
  background-color: var(--main-color1);
  height: 100%;
  margin-left: 240px;
  margin-top: 56px;
}
.popular {
}
h1 {
  font-size: 1.75rem;
  letter-spacing: 0.0175rem;
  font-family: Inter;
  color: #fff;
}
.list > img {
  width: 216px;
  height: 216px;
  border-radius: 4px;
}
.list {
}
</style>